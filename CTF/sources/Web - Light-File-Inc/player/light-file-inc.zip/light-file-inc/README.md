
```sh
docker-compose up -d --build
```

or

```sh
docker-compose up
```