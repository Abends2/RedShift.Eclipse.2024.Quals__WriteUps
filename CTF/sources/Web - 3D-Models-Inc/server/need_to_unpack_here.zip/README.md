```sh
docker-compose up -d --build
```
