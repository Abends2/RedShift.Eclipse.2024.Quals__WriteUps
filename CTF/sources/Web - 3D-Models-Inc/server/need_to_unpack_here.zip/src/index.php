<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Keyboard & Mouse | Login</title>
        <meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
        <link rel="stylesheet" type="text/css" href="static/css/index.css"/>
        <link rel="icon" href="static/img/keyboard.ico">
    </head>
    <body>
        <div class="forms-wrapper">
            <div class="login-form-wrapper">
                <h3 class="alert">Login</h3>
                <form action="login.php" method="POST">
                    <div class="form-group">
                        &emsp;&emsp;<label>Username</label><br>
                        <input type="text" name="username" class="form-control" required="required"/>
                    </div><br>

                    <div class="form-group">
                        &emsp;&emsp;<label>Password</label><br>
                        <input type="password" name="password" class="form-control" required="required"/>
                    </div><br><br>
    
                    <button name="login" class="btn-login">Login</button>
                </form>
            </div>

            <div class="register-form-wrapper">
                <h3 class="alert">Register</h3>
                <form action="" method="POST">
                    <div class="form-group">
                        &emsp;&emsp;<label>Name</label><br>
                        <input type="text" name="name" class="form-control" required="required"/>
                    </div><br>

                    <div class="form-group">
                        &emsp;&emsp;<label>Username</label><br>
                        <input type="text" name="username" class="form-control" required="required"/>
                    </div><br>

                    <div class="form-group">
                        &emsp;&emsp;<label>Password</label><br>
                        <input type="password" name="password" class="form-control" required="required"/>
                    </div><br><br>
    
                    <button name="register" class="btn-register">Register</button>
                </form>
                <?php include 'register.php'?>
            </div>
        </div>
    </body>
</html>