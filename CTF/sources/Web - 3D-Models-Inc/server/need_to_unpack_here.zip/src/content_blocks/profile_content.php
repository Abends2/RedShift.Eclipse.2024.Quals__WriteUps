<?php
    session_start();
    if(!isset($_SESSION['user_id'])){
        header('location: index.php');
    }
?>

<link rel="stylesheet" type="text/css" href="static/css/profile.css">

<div class="profile-block-wrapper">
    <div class="card">
        <div class="pfp">
            <img src="static/img/profile.jpg" alt="catPhoto">
            <h2>Name: <?php echo $_SESSION['username'] ?>
            </h2>
            <h4>Username ID: 
                <?php 
                    if ($_SESSION['admin'] == "True") {
                        echo "EclipseCTF{n0t_3v3n_gh0st5";
                    } else {
                        echo "Ha-ha, no flag for this user!";
                    }
                ?>
            </h4>
        </div>

        <p class="intro">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

        <form method="get" action="logout.php">
            <button class="btn-logout" type="submit">Logout</button>
        </form>

    </div>
</div>

