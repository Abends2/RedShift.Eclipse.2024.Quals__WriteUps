<div class="body-page-wrapper">
    <?php
        for($i = 0; $i < 3; $i++):
    ?>
    <div class="center">
        <div class="article-card">
            <div class="content">
                <p class="date">Keyboard/mouse vendor</p>
                <p class="title">Keyboard/mouse title & description</p>
            </div>
            <img src="static/img/<?php echo ($i + 1)?>.jpg" alt="article-cover" />
        </div>
    </div>
    <?php endfor; ?>
</div>

<div class="body-page-wrapper">
    <?php
        for($i = 3; $i < 6; $i++):
    ?>
    <div class="center">
        <div class="article-card">
            <div class="content">
                <p class="date">Keyboard/mouse vendor</p>
                <p class="title">Keyboard/mouse title & description</p>
            </div>
            <img src="static/img/<?php echo ($i + 1)?>.jpg" alt="article-cover" />
        </div>
    </div>
    <?php endfor; ?>
</div>