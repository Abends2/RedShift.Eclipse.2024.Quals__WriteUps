<link rel="stylesheet" type="text/css" href="static/css/about-us.css">

<div class="about-us-block-wrapper">
    <h2>&#128293;</h2>
    <h2 class="purples">We are</h2>
    <h2 class="mint">Keyboard & Mouse LLC!</h2>
    <br> 
    <h2 class="purples">Welcome!</h2>
    <p>(the best devices for everyone!)</p>
</div>