<?php
    require_once 'conn.php';
    if (isset($_POST['register'])){
        $name = $_POST['name'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $is_admin = $_POST['is_admin'] ?? 'False';
 
        $query = "INSERT INTO `user` (name, username, password, is_admin) VALUES ('$name', '$username', '$password', '$is_admin')";
 
        $conn -> exec($query);
        echo "<center><h4 class='text-success' style='color: lime;'>Successfully registered!</h4></center>";
    }
?>