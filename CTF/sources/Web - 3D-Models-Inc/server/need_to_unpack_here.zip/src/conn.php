<?php
    $conn = new SQLite3('database/service-db.db') or die("Unable to open database!");
    
    $query = "CREATE TABLE IF NOT EXISTS `user` (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, 
        username TEXT NOT NULL, 
        password TEXT NOT NULL, 
        name TEXT NOT NULL,
        is_admin BOOLEAN NOT NULL
    )";    

    $conn -> exec($query);
?>