<?php
    session_start();
    if (!isset($_SESSION['user_id'])){
        header('location: index.php');
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Keyboard & Mouse | Shop</title>
	    <link rel="stylesheet" type="text/css" href="static/css/home.css">
        <link rel="icon" href="static/img/keyboard.ico">
    </head>

    <body>
        <header class="header-main">
            <div class="menu">
                <a href="home.php">Main</a>
                <a href="home.php?view=about-us_content.php">About Us</a>
                <a href="home.php?view=profile_content.php">Profile</a>
            </div>
        </header>

        <?php
            if (!isset($_GET['view']) || ($_GET['view'] == "home.php")) {
                require "content_blocks/home_content.php";
            } else {
                echo "<section>";
                include("/var/www/html/content_blocks/" .$_GET['view']);
                echo "</section>";
            }
        ?>

        <footer class="footer-main">
            <p class="footer-text">&emsp;&emsp;&emsp;&emsp;&copy; Keyboard Shop <?php echo date("Y"); ?>. Privacy Policy</p>
        </footer>
    </body>
</html>